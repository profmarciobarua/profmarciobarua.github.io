var texto = "Hello World";
    
function imprimirTexto(textoParaImprimir) {
   console.log(textoParaImprimir);
}

imprimirTexto(texto);